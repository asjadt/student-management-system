<?php

namespace App\Http\Middleware;

use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class FormatDatesInResponse
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);

        if ($response instanceof JsonResponse) {
            $response->setData($this->formatDates($response->getData()));
        }

        return $response;
    }

    protected function formatDates($data)
    {
        if (is_array($data)) {
            // Recursively format dates within arrays/objects
            array_walk_recursive($data, function (&$value, $key) {
                if ($value instanceof Carbon) {
                    $value = $value->format('d-m-Y');
                }
            });
        } elseif ($data instanceof Carbon) {
            // Format the top-level Carbon instance
            $data = $data->format('d-m-Y');
        }

        return $data;
    }
}
