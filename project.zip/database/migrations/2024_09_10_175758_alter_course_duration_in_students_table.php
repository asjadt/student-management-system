<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class AlterCourseDurationInStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Rename the existing column to a temporary name
        Schema::table('students', function (Blueprint $table) {
            $table->renameColumn('course_duration', 'course_duration_temp');
        });

        // Add the new column with the correct type
        Schema::table('students', function (Blueprint $table) {
            $table->string('course_duration')->nullable();
        });

        // Copy data from the old column to the new column
        DB::table('students')->update([
            'course_duration' => DB::raw('course_duration_temp')
        ]);

        // Drop the old column
        Schema::table('students', function (Blueprint $table) {
            $table->dropColumn('course_duration_temp');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Rename the existing column to a temporary name
        Schema::table('students', function (Blueprint $table) {
            $table->renameColumn('course_duration', 'course_duration_temp');
        });

        // Add the old column type
        Schema::table('students', function (Blueprint $table) {
            $table->date('course_duration')->nullable();
        });

        // Copy data from the new column to the old column
        DB::table('students')->update([
            'course_duration' => DB::raw('course_duration_temp')
        ]);

        // Drop the new column
        Schema::table('students', function (Blueprint $table) {
            $table->dropColumn('course_duration_temp');
        });
    }
}
